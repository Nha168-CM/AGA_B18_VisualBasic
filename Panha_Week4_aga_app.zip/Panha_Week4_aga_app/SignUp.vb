﻿Public Class SignUp
    Private Sub Guna2HtmlLabel2_Click(sender As Object, e As EventArgs)

    End Sub



    Private Sub Gbt_close1_Click(sender As Object, e As EventArgs) Handles Gbt_close1.Click
        Me.Close()
        Me.Hide()
    End Sub

    Private Sub txt_Un_GotFocus(sender As Object, e As EventArgs) Handles txt_Un.GotFocus
        If txt_Un.Text = "User Name" Then
            txt_Un.Text = ""
            txt_Un.ForeColor = Color.DimGray
        End If
    End Sub

    Private Sub txt_Un_LostFocus(sender As Object, e As EventArgs) Handles txt_Un.LostFocus
        If txt_Un.Text = "" Then
            txt_Un.Text = "User Name"
            txt_Un.ForeColor = Color.DarkGray
        End If
    End Sub

    Private Sub txt_Pw_GotFocus(sender As Object, e As EventArgs) Handles txt_Pw.GotFocus
        If txt_Pw.Text = "Password" Then
            txt_Pw.Text = ""
            txt_Pw.PasswordChar = "•"
            txt_Pw.ForeColor = Color.DimGray
        End If
    End Sub

    Private Sub txt_Pw_LostFocus(sender As Object, e As EventArgs) Handles txt_Pw.LostFocus
        If txt_Pw.Text = "" Then
            txt_Pw.Text = "Password"
            txt_Pw.ForeColor = Color.DarkGray
        End If


    End Sub

    Private Sub txt_Rpw_GotFocus(sender As Object, e As EventArgs) Handles txt_Rpw.GotFocus
        If txt_Rpw.Text = "Re-Enter Password" Then
            txt_Rpw.Text = ""
            txt_Rpw.PasswordChar = "•"
            txt_Rpw.ForeColor = Color.DimGray
        End If
    End Sub

    Private Sub txt_Rpw_LostFocus(sender As Object, e As EventArgs) Handles txt_Rpw.LostFocus
        If txt_Rpw.Text = "" Then
            txt_Rpw.Text = "Re-Enter Password"
            txt_Rpw.ForeColor = Color.DarkGray

        End If


    End Sub

    Private Sub txt_Em_GotFocus(sender As Object, e As EventArgs) Handles txt_Em.GotFocus
        If txt_Em.Text = "Email" Then
            txt_Em.Text = ""
            txt_Em.ForeColor = Color.DimGray
        End If


    End Sub

    Private Sub txt_Em_LostFocus(sender As Object, e As EventArgs) Handles txt_Em.LostFocus
        If txt_Em.Text = "" Then
            txt_Em.Text = "Email"
            txt_Em.ForeColor = Color.DarkGray
        End If
    End Sub
End Class
