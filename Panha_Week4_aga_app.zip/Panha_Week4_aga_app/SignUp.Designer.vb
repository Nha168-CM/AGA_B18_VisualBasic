﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SignUp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Gbt_close1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Gbt_Close = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Check_Save = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.Btn_Su = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2GradientPanel5 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.txt_Em = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GradientPanel4 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.txt_Rpw = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GradientPanel3 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.txt_Pw = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GradientPanel2 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.txt_Un = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GradientPanel1.SuspendLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.Gbt_close1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Gbt_Close, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.Controls.Add(Me.Label6)
        Me.Guna2GradientPanel1.Controls.Add(Me.Label5)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2GradientPanel1.Controls.Add(Me.Panel1)
        Me.Guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.LightSeaGreen
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.BlueViolet
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(820, 800)
        Me.Guna2GradientPanel1.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Noto Sans Khmer UI", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(105, 354)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(142, 32)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Ui Academy"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Noto Sans Khmer UI", 10.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(32, 421)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(273, 23)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "We Create, We Design, We Delelop"
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox1.BackgroundImage = Global.Panha_Week4_aga_app.My.Resources.Resources.c_sharp
        Me.Guna2PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Guna2PictureBox1.Image = Global.Panha_Week4_aga_app.My.Resources.Resources.c_sharp__1_
        Me.Guna2PictureBox1.ImageRotate = 0!
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(86, 192)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(182, 159)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox1.TabIndex = 1
        Me.Guna2PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Gbt_close1)
        Me.Panel1.Controls.Add(Me.Gbt_Close)
        Me.Panel1.Controls.Add(Me.Check_Save)
        Me.Panel1.Controls.Add(Me.Btn_Su)
        Me.Panel1.Controls.Add(Me.Guna2GradientPanel5)
        Me.Panel1.Controls.Add(Me.txt_Em)
        Me.Panel1.Controls.Add(Me.Guna2GradientPanel4)
        Me.Panel1.Controls.Add(Me.txt_Rpw)
        Me.Panel1.Controls.Add(Me.Guna2GradientPanel3)
        Me.Panel1.Controls.Add(Me.txt_Pw)
        Me.Panel1.Controls.Add(Me.Guna2GradientPanel2)
        Me.Panel1.Controls.Add(Me.txt_Un)
        Me.Panel1.Location = New System.Drawing.Point(357, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(463, 800)
        Me.Panel1.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Noto Sans Khmer UI", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label7.Location = New System.Drawing.Point(13, 59)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(183, 53)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Sign Up"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Noto Sans Khmer UI", 10.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label4.Location = New System.Drawing.Point(18, 394)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(159, 23)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Re-Enter Password:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Noto Sans Khmer UI", 10.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(18, 504)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 23)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Email:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Noto Sans Khmer UI", 10.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(18, 282)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 23)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Password:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Noto Sans Khmer UI", 10.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.Location = New System.Drawing.Point(18, 159)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 23)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "User Name:"
        '
        'Gbt_close1
        '
        Me.Gbt_close1.BackColor = System.Drawing.Color.Transparent
        Me.Gbt_close1.FillColor = System.Drawing.SystemColors.Highlight
        Me.Gbt_close1.Image = Global.Panha_Week4_aga_app.My.Resources.Resources._11244080_x_twitter_elon_musk_twitter_new_logo_icon
        Me.Gbt_close1.ImageRotate = 0!
        Me.Gbt_close1.Location = New System.Drawing.Point(424, 3)
        Me.Gbt_close1.Name = "Gbt_close1"
        Me.Gbt_close1.Size = New System.Drawing.Size(34, 30)
        Me.Gbt_close1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Gbt_close1.TabIndex = 20
        Me.Gbt_close1.TabStop = False
        '
        'Gbt_Close
        '
        Me.Gbt_Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Gbt_Close.FillColor = System.Drawing.Color.Transparent
        Me.Gbt_Close.Image = Global.Panha_Week4_aga_app.My.Resources.Resources._11244080_x_twitter_elon_musk_twitter_new_logo_icon
        Me.Gbt_Close.ImageRotate = 0!
        Me.Gbt_Close.Location = New System.Drawing.Point(542, 3)
        Me.Gbt_Close.Name = "Gbt_Close"
        Me.Gbt_Close.Size = New System.Drawing.Size(36, 35)
        Me.Gbt_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Gbt_Close.TabIndex = 19
        Me.Gbt_Close.TabStop = False
        '
        'Check_Save
        '
        Me.Check_Save.AutoSize = True
        Me.Check_Save.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Check_Save.CheckedState.BorderRadius = 0
        Me.Check_Save.CheckedState.BorderThickness = 0
        Me.Check_Save.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Check_Save.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Check_Save.ForeColor = System.Drawing.Color.DarkBlue
        Me.Check_Save.Location = New System.Drawing.Point(22, 589)
        Me.Check_Save.Name = "Check_Save"
        Me.Check_Save.Size = New System.Drawing.Size(294, 29)
        Me.Check_Save.TabIndex = 18
        Me.Check_Save.Text = "I Agree Terms and Conditions"
        Me.Check_Save.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Check_Save.UncheckedState.BorderRadius = 0
        Me.Check_Save.UncheckedState.BorderThickness = 0
        Me.Check_Save.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        '
        'Btn_Su
        '
        Me.Btn_Su.Animated = True
        Me.Btn_Su.AutoRoundedCorners = True
        Me.Btn_Su.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Su.BorderColor = System.Drawing.Color.SkyBlue
        Me.Btn_Su.BorderRadius = 29
        Me.Btn_Su.BorderThickness = 2
        Me.Btn_Su.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Btn_Su.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Btn_Su.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Su.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Btn_Su.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Btn_Su.Font = New System.Drawing.Font("Segoe UI", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Btn_Su.ForeColor = System.Drawing.Color.White
        Me.Btn_Su.Location = New System.Drawing.Point(109, 658)
        Me.Btn_Su.Name = "Btn_Su"
        Me.Btn_Su.Size = New System.Drawing.Size(268, 60)
        Me.Btn_Su.TabIndex = 17
        Me.Btn_Su.Text = "Sign Up"
        '
        'Guna2GradientPanel5
        '
        Me.Guna2GradientPanel5.AutoRoundedCorners = True
        Me.Guna2GradientPanel5.BorderRadius = 1
        Me.Guna2GradientPanel5.FillColor = System.Drawing.Color.SkyBlue
        Me.Guna2GradientPanel5.FillColor2 = System.Drawing.Color.HotPink
        Me.Guna2GradientPanel5.Location = New System.Drawing.Point(22, 569)
        Me.Guna2GradientPanel5.Name = "Guna2GradientPanel5"
        Me.Guna2GradientPanel5.Size = New System.Drawing.Size(408, 4)
        Me.Guna2GradientPanel5.TabIndex = 16
        '
        'txt_Em
        '
        Me.txt_Em.Animated = True
        Me.txt_Em.BorderColor = System.Drawing.Color.DarkViolet
        Me.txt_Em.BorderRadius = 5
        Me.txt_Em.BorderThickness = 0
        Me.txt_Em.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Em.DefaultText = ""
        Me.txt_Em.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_Em.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_Em.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Em.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Em.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Em.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_Em.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Em.Location = New System.Drawing.Point(22, 531)
        Me.txt_Em.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_Em.Name = "txt_Em"
        Me.txt_Em.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_Em.PlaceholderText = ""
        Me.txt_Em.SelectedText = ""
        Me.txt_Em.Size = New System.Drawing.Size(408, 42)
        Me.txt_Em.TabIndex = 15
        '
        'Guna2GradientPanel4
        '
        Me.Guna2GradientPanel4.AutoRoundedCorners = True
        Me.Guna2GradientPanel4.BorderRadius = 1
        Me.Guna2GradientPanel4.FillColor = System.Drawing.Color.SkyBlue
        Me.Guna2GradientPanel4.FillColor2 = System.Drawing.Color.HotPink
        Me.Guna2GradientPanel4.Location = New System.Drawing.Point(22, 459)
        Me.Guna2GradientPanel4.Name = "Guna2GradientPanel4"
        Me.Guna2GradientPanel4.Size = New System.Drawing.Size(408, 4)
        Me.Guna2GradientPanel4.TabIndex = 13
        '
        'txt_Rpw
        '
        Me.txt_Rpw.Animated = True
        Me.txt_Rpw.BorderColor = System.Drawing.Color.DarkViolet
        Me.txt_Rpw.BorderRadius = 5
        Me.txt_Rpw.BorderThickness = 0
        Me.txt_Rpw.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Rpw.DefaultText = ""
        Me.txt_Rpw.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_Rpw.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_Rpw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Rpw.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Rpw.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Rpw.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_Rpw.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Rpw.Location = New System.Drawing.Point(22, 421)
        Me.txt_Rpw.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_Rpw.Name = "txt_Rpw"
        Me.txt_Rpw.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_Rpw.PlaceholderText = ""
        Me.txt_Rpw.SelectedText = ""
        Me.txt_Rpw.Size = New System.Drawing.Size(408, 42)
        Me.txt_Rpw.TabIndex = 12
        '
        'Guna2GradientPanel3
        '
        Me.Guna2GradientPanel3.AutoRoundedCorners = True
        Me.Guna2GradientPanel3.BorderRadius = 1
        Me.Guna2GradientPanel3.FillColor = System.Drawing.Color.SkyBlue
        Me.Guna2GradientPanel3.FillColor2 = System.Drawing.Color.HotPink
        Me.Guna2GradientPanel3.Location = New System.Drawing.Point(22, 347)
        Me.Guna2GradientPanel3.Name = "Guna2GradientPanel3"
        Me.Guna2GradientPanel3.Size = New System.Drawing.Size(408, 4)
        Me.Guna2GradientPanel3.TabIndex = 10
        '
        'txt_Pw
        '
        Me.txt_Pw.Animated = True
        Me.txt_Pw.BorderColor = System.Drawing.Color.DarkViolet
        Me.txt_Pw.BorderRadius = 5
        Me.txt_Pw.BorderThickness = 0
        Me.txt_Pw.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Pw.DefaultText = ""
        Me.txt_Pw.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_Pw.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_Pw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Pw.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Pw.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Pw.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_Pw.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Pw.Location = New System.Drawing.Point(22, 309)
        Me.txt_Pw.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_Pw.Name = "txt_Pw"
        Me.txt_Pw.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_Pw.PlaceholderText = ""
        Me.txt_Pw.SelectedText = ""
        Me.txt_Pw.Size = New System.Drawing.Size(408, 42)
        Me.txt_Pw.TabIndex = 9
        '
        'Guna2GradientPanel2
        '
        Me.Guna2GradientPanel2.AutoRoundedCorners = True
        Me.Guna2GradientPanel2.BorderRadius = 1
        Me.Guna2GradientPanel2.FillColor = System.Drawing.Color.SkyBlue
        Me.Guna2GradientPanel2.FillColor2 = System.Drawing.Color.HotPink
        Me.Guna2GradientPanel2.Location = New System.Drawing.Point(22, 224)
        Me.Guna2GradientPanel2.Name = "Guna2GradientPanel2"
        Me.Guna2GradientPanel2.Size = New System.Drawing.Size(408, 4)
        Me.Guna2GradientPanel2.TabIndex = 7
        '
        'txt_Un
        '
        Me.txt_Un.Animated = True
        Me.txt_Un.BorderColor = System.Drawing.Color.DarkViolet
        Me.txt_Un.BorderRadius = 5
        Me.txt_Un.BorderThickness = 0
        Me.txt_Un.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Un.DefaultText = ""
        Me.txt_Un.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_Un.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_Un.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Un.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Un.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Un.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_Un.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Un.Location = New System.Drawing.Point(22, 186)
        Me.txt_Un.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txt_Un.Name = "txt_Un"
        Me.txt_Un.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_Un.PlaceholderText = ""
        Me.txt_Un.SelectedText = ""
        Me.txt_Un.Size = New System.Drawing.Size(408, 42)
        Me.txt_Un.TabIndex = 6
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(820, 800)
        Me.Controls.Add(Me.Guna2GradientPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.Gbt_close1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Gbt_Close, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents txt_Un As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GradientPanel2 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Guna2GradientPanel5 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents txt_Em As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GradientPanel4 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents txt_Rpw As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GradientPanel3 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents txt_Pw As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Btn_Su As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Gbt_Close As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Check_Save As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents Gbt_close1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label7 As Label
End Class
