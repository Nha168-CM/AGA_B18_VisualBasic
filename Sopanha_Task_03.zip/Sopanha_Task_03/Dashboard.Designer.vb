﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2PictureBox5 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox4 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.BtnWa = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnTe = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnFb = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnMenu = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnHome = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.BtnMini = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnMax = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnClose = New Guna.UI2.WinForms.Guna2Button()
        Me.Panel1.SuspendLayout()
        Me.Guna2Panel3.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        Me.Guna2Panel1.SuspendLayout()
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Guna2Panel3)
        Me.Panel1.Controls.Add(Me.Guna2Panel2)
        Me.Panel1.Controls.Add(Me.Guna2Panel1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(900, 700)
        Me.Panel1.TabIndex = 0
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.Controls.Add(Me.Guna2PictureBox5)
        Me.Guna2Panel3.Controls.Add(Me.Guna2PictureBox4)
        Me.Guna2Panel3.Controls.Add(Me.Guna2PictureBox3)
        Me.Guna2Panel3.Controls.Add(Me.Guna2PictureBox2)
        Me.Guna2Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2Panel3.FillColor = System.Drawing.Color.LightGray
        Me.Guna2Panel3.Location = New System.Drawing.Point(250, 35)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.Size = New System.Drawing.Size(650, 665)
        Me.Guna2Panel3.TabIndex = 2
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.Controls.Add(Me.BtnWa)
        Me.Guna2Panel2.Controls.Add(Me.BtnTe)
        Me.Guna2Panel2.Controls.Add(Me.BtnFb)
        Me.Guna2Panel2.Controls.Add(Me.BtnMenu)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button2)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button1)
        Me.Guna2Panel2.Controls.Add(Me.BtnHome)
        Me.Guna2Panel2.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Guna2Panel2.FillColor = System.Drawing.SystemColors.MenuBar
        Me.Guna2Panel2.Location = New System.Drawing.Point(0, 35)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.Size = New System.Drawing.Size(250, 665)
        Me.Guna2Panel2.TabIndex = 1
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Controls.Add(Me.BtnMini)
        Me.Guna2Panel1.Controls.Add(Me.BtnMax)
        Me.Guna2Panel1.Controls.Add(Me.BtnClose)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel1.FillColor = System.Drawing.SystemColors.MenuBar
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.Size = New System.Drawing.Size(900, 35)
        Me.Guna2Panel1.TabIndex = 0
        '
        'Guna2PictureBox5
        '
        Me.Guna2PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox5.FillColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox5.Image = Global.Sopanha_Task_03.My.Resources.Resources.diagram
        Me.Guna2PictureBox5.ImageRotate = 0!
        Me.Guna2PictureBox5.Location = New System.Drawing.Point(389, 350)
        Me.Guna2PictureBox5.Name = "Guna2PictureBox5"
        Me.Guna2PictureBox5.Size = New System.Drawing.Size(220, 220)
        Me.Guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox5.TabIndex = 3
        Me.Guna2PictureBox5.TabStop = False
        '
        'Guna2PictureBox4
        '
        Me.Guna2PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox4.FillColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox4.Image = Global.Sopanha_Task_03.My.Resources.Resources.bar_chart
        Me.Guna2PictureBox4.ImageRotate = 0!
        Me.Guna2PictureBox4.Location = New System.Drawing.Point(388, 65)
        Me.Guna2PictureBox4.Name = "Guna2PictureBox4"
        Me.Guna2PictureBox4.Size = New System.Drawing.Size(220, 220)
        Me.Guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox4.TabIndex = 2
        Me.Guna2PictureBox4.TabStop = False
        '
        'Guna2PictureBox3
        '
        Me.Guna2PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox3.FillColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox3.Image = Global.Sopanha_Task_03.My.Resources.Resources.organization_chart
        Me.Guna2PictureBox3.ImageRotate = 0!
        Me.Guna2PictureBox3.Location = New System.Drawing.Point(64, 350)
        Me.Guna2PictureBox3.Name = "Guna2PictureBox3"
        Me.Guna2PictureBox3.Size = New System.Drawing.Size(220, 220)
        Me.Guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox3.TabIndex = 1
        Me.Guna2PictureBox3.TabStop = False
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox2.FillColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox2.Image = Global.Sopanha_Task_03.My.Resources.Resources.pie_chart
        Me.Guna2PictureBox2.ImageRotate = 0!
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(64, 65)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(220, 220)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox2.TabIndex = 0
        Me.Guna2PictureBox2.TabStop = False
        '
        'BtnWa
        '
        Me.BtnWa.BackColor = System.Drawing.Color.Transparent
        Me.BtnWa.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnWa.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnWa.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnWa.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnWa.FillColor = System.Drawing.Color.Transparent
        Me.BtnWa.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnWa.ForeColor = System.Drawing.Color.White
        Me.BtnWa.Image = Global.Sopanha_Task_03.My.Resources.Resources.whatsapp
        Me.BtnWa.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnWa.Location = New System.Drawing.Point(150, 592)
        Me.BtnWa.Name = "BtnWa"
        Me.BtnWa.Size = New System.Drawing.Size(40, 40)
        Me.BtnWa.TabIndex = 6
        '
        'BtnTe
        '
        Me.BtnTe.BackColor = System.Drawing.Color.Transparent
        Me.BtnTe.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnTe.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnTe.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnTe.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnTe.FillColor = System.Drawing.Color.Transparent
        Me.BtnTe.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnTe.ForeColor = System.Drawing.Color.White
        Me.BtnTe.Image = Global.Sopanha_Task_03.My.Resources.Resources.telegram
        Me.BtnTe.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnTe.Location = New System.Drawing.Point(104, 592)
        Me.BtnTe.Name = "BtnTe"
        Me.BtnTe.Size = New System.Drawing.Size(40, 40)
        Me.BtnTe.TabIndex = 5
        '
        'BtnFb
        '
        Me.BtnFb.BackColor = System.Drawing.Color.Transparent
        Me.BtnFb.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnFb.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnFb.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnFb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnFb.FillColor = System.Drawing.Color.Transparent
        Me.BtnFb.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnFb.ForeColor = System.Drawing.Color.White
        Me.BtnFb.Image = Global.Sopanha_Task_03.My.Resources.Resources.facebook
        Me.BtnFb.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnFb.Location = New System.Drawing.Point(58, 592)
        Me.BtnFb.Name = "BtnFb"
        Me.BtnFb.Size = New System.Drawing.Size(40, 40)
        Me.BtnFb.TabIndex = 4
        '
        'BtnMenu
        '
        Me.BtnMenu.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnMenu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnMenu.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnMenu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnMenu.FillColor = System.Drawing.Color.Transparent
        Me.BtnMenu.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnMenu.ForeColor = System.Drawing.Color.White
        Me.BtnMenu.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_menu_96
        Me.BtnMenu.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnMenu.Location = New System.Drawing.Point(210, 0)
        Me.BtnMenu.Name = "BtnMenu"
        Me.BtnMenu.Size = New System.Drawing.Size(40, 40)
        Me.BtnMenu.TabIndex = 3
        '
        'Guna2Button2
        '
        Me.Guna2Button2.BorderRadius = 6
        Me.Guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button2.FillColor = System.Drawing.Color.LightGray
        Me.Guna2Button2.Font = New System.Drawing.Font("AKbalthom Freehand", 10.8!)
        Me.Guna2Button2.ForeColor = System.Drawing.Color.Red
        Me.Guna2Button2.HoverState.FillColor = System.Drawing.Color.Red
        Me.Guna2Button2.HoverState.ForeColor = System.Drawing.Color.White
        Me.Guna2Button2.HoverState.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_logout_96__3_
        Me.Guna2Button2.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_logout_96__2_
        Me.Guna2Button2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button2.ImageSize = New System.Drawing.Size(30, 30)
        Me.Guna2Button2.Location = New System.Drawing.Point(12, 452)
        Me.Guna2Button2.Name = "Guna2Button2"
        Me.Guna2Button2.Size = New System.Drawing.Size(232, 45)
        Me.Guna2Button2.TabIndex = 2
        Me.Guna2Button2.Text = "ទំព័រដើម"
        Me.Guna2Button2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault
        '
        'Guna2Button1
        '
        Me.Guna2Button1.BorderRadius = 6
        Me.Guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button1.FillColor = System.Drawing.Color.LightGray
        Me.Guna2Button1.Font = New System.Drawing.Font("AKbalthom Freehand", 10.8!)
        Me.Guna2Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.Guna2Button1.HoverState.FillColor = System.Drawing.Color.LightSkyBlue
        Me.Guna2Button1.HoverState.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Guna2Button1.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_cog_96
        Me.Guna2Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button1.ImageSize = New System.Drawing.Size(30, 30)
        Me.Guna2Button1.Location = New System.Drawing.Point(12, 401)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.Size = New System.Drawing.Size(232, 45)
        Me.Guna2Button1.TabIndex = 1
        Me.Guna2Button1.Text = "ការកំណត់"
        Me.Guna2Button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.Guna2Button1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault
        '
        'BtnHome
        '
        Me.BtnHome.BorderRadius = 6
        Me.BtnHome.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnHome.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnHome.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnHome.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnHome.FillColor = System.Drawing.Color.LightGray
        Me.BtnHome.Font = New System.Drawing.Font("AKbalthom Freehand", 10.8!)
        Me.BtnHome.ForeColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.BtnHome.HoverState.FillColor = System.Drawing.Color.LightSkyBlue
        Me.BtnHome.HoverState.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.BtnHome.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_home_96
        Me.BtnHome.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BtnHome.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnHome.Location = New System.Drawing.Point(12, 215)
        Me.BtnHome.Name = "BtnHome"
        Me.BtnHome.Size = New System.Drawing.Size(232, 45)
        Me.BtnHome.TabIndex = 0
        Me.BtnHome.Text = "ទំព័រដើម"
        Me.BtnHome.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BtnHome.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.Sopanha_Task_03.My.Resources.Resources.login
        Me.Guna2PictureBox1.ImageRotate = 0!
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(50, 65)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(150, 125)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox1.TabIndex = 0
        Me.Guna2PictureBox1.TabStop = False
        '
        'BtnMini
        '
        Me.BtnMini.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnMini.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnMini.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnMini.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnMini.FillColor = System.Drawing.Color.Transparent
        Me.BtnMini.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnMini.ForeColor = System.Drawing.Color.White
        Me.BtnMini.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_minimize_window_96
        Me.BtnMini.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnMini.Location = New System.Drawing.Point(783, -1)
        Me.BtnMini.Name = "BtnMini"
        Me.BtnMini.Size = New System.Drawing.Size(35, 35)
        Me.BtnMini.TabIndex = 5
        '
        'BtnMax
        '
        Me.BtnMax.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnMax.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnMax.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnMax.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnMax.FillColor = System.Drawing.Color.Transparent
        Me.BtnMax.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnMax.ForeColor = System.Drawing.Color.White
        Me.BtnMax.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_maximize_window_96
        Me.BtnMax.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnMax.Location = New System.Drawing.Point(824, 0)
        Me.BtnMax.Name = "BtnMax"
        Me.BtnMax.Size = New System.Drawing.Size(35, 35)
        Me.BtnMax.TabIndex = 6
        '
        'BtnClose
        '
        Me.BtnClose.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnClose.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnClose.FillColor = System.Drawing.Color.Transparent
        Me.BtnClose.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BtnClose.ForeColor = System.Drawing.Color.White
        Me.BtnClose.Image = Global.Sopanha_Task_03.My.Resources.Resources.icons8_close_96
        Me.BtnClose.ImageSize = New System.Drawing.Size(30, 30)
        Me.BtnClose.Location = New System.Drawing.Point(865, 0)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(35, 35)
        Me.BtnClose.TabIndex = 4
        '
        'Dashboard
        '
        Me.ClientSize = New System.Drawing.Size(900, 700)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Dashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.Guna2Panel3.ResumeLayout(False)
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel1.ResumeLayout(False)
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents BtnHome As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnMenu As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnClose As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnMini As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnMax As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox5 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox4 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents BtnTe As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnFb As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnWa As Guna.UI2.WinForms.Guna2Button
End Class
