﻿Public Class Login


    Private Sub Login_Load(sender As Object, e As EventArgs) Handles Me.Load
        txtuser.Text = "គណនីប្រើប្រាស់ | Username"
        txtuser.ForeColor = Color.DarkGray

        txtPw.Text = "លេខងសម្ងាត់ | Password"
        txtPw.ForeColor = Color.DarkGray
        txtuser.Text = ""
        txtPw.Text = ""
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub


    Private Sub txtuser_GotFocus(sender As Object, e As EventArgs) Handles txtuser.GotFocus
        If txtuser.Text = "គណនីប្រើប្រាស់ | Username" Then
            txtuser.Text = ""
            txtuser.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtuser_LostFocus(sender As Object, e As EventArgs) Handles txtuser.LostFocus
        If txtuser.Text = "" Then
            txtuser.Text = "គណនីប្រើប្រាស់ | Username"
            txtuser.ForeColor = Color.DarkGray
        End If
    End Sub

    Private Sub txtPw_GotFocus(sender As Object, e As EventArgs) Handles txtPw.GotFocus
        If txtPw.Text = "លេខងសម្ងាត់ | Password" Then
            txtPw.Text = ""
            txtPw.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtPw_LostFocus(sender As Object, e As EventArgs) Handles txtPw.LostFocus
        If txtPw.Text = "" Then
            txtPw.Text = "លេខងសម្ងាត់ | Password"
            txtPw.PasswordChar = "●"
            txtPw.ForeColor = Color.DarkGray
        End If
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Dim adminUsername As String = "admin"
        Dim adminPassword As String = "admin123"
        Dim userUsername As String = "user"
        Dim userPassword As String = "user123"

        Dim enteredUsername As String = txtuser.Text.Trim()
        Dim enteredPassword As String = txtPw.Text.Trim()


        If enteredUsername = adminUsername AndAlso enteredPassword = adminPassword Then
            MessageBox.Show("Login Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            Dashboard.Show()

        ElseIf enteredUsername = userUsername AndAlso enteredPassword = userPassword Then
            MessageBox.Show("Login Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            Student.Show()

        Else
            MessageBox.Show("Invalid username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub

    Private Sub Checkbox_CheckedChanged(sender As Object, e As EventArgs) Handles checkPw.CheckedChanged
        If checkPw.Checked = False Then
            txtuser.PasswordChar = ""
        Else
            txtPw.PasswordChar = "●"
        End If
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        txtuser.Text = ""
        txtPw.Text = ""
    End Sub
End Class
