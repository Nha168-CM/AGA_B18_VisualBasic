﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Login1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.txtuser = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtPw = New Guna.UI2.WinForms.Guna2TextBox()
        Me.checkPw = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.BtnLogin = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.BtnCancel = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.BtnSignup = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.BtnClose = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2CircleProgressBar1 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar2 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar3 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar4 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar5 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar6 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar7 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar8 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar9 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar10 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar11 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar12 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar13 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar14 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Guna2CircleProgressBar15 = New Guna.UI2.WinForms.Guna2CircleProgressBar()
        Me.Login1.SuspendLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Login1
        '
        Me.Login1.BackColor = System.Drawing.Color.White
        Me.Login1.BorderRadius = 20
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar15)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar14)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar13)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar12)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar11)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar10)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar9)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar8)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar7)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar6)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar5)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar4)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar3)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar2)
        Me.Login1.Controls.Add(Me.Guna2CircleProgressBar1)
        Me.Login1.Controls.Add(Me.BtnClose)
        Me.Login1.Controls.Add(Me.BtnSignup)
        Me.Login1.Controls.Add(Me.BtnCancel)
        Me.Login1.Controls.Add(Me.BtnLogin)
        Me.Login1.Controls.Add(Me.checkPw)
        Me.Login1.Controls.Add(Me.txtPw)
        Me.Login1.Controls.Add(Me.txtuser)
        Me.Login1.Controls.Add(Me.Guna2PictureBox1)
        Me.Login1.Location = New System.Drawing.Point(0, 0)
        Me.Login1.Name = "Login1"
        Me.Login1.Size = New System.Drawing.Size(500, 600)
        Me.Login1.TabIndex = 0
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.Sopanha_Task_03.My.Resources.Resources.login
        Me.Guna2PictureBox1.ImageRotate = 0!
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(180, 60)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(150, 150)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox1.TabIndex = 0
        Me.Guna2PictureBox1.TabStop = False
        '
        'txtuser
        '
        Me.txtuser.Animated = True
        Me.txtuser.BorderColor = System.Drawing.Color.SkyBlue
        Me.txtuser.BorderRadius = 10
        Me.txtuser.BorderThickness = 2
        Me.txtuser.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtuser.DefaultText = ""
        Me.txtuser.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtuser.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtuser.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtuser.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtuser.FillColor = System.Drawing.SystemColors.Menu
        Me.txtuser.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtuser.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtuser.ForeColor = System.Drawing.Color.DarkGray
        Me.txtuser.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtuser.Location = New System.Drawing.Point(55, 220)
        Me.txtuser.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtuser.Name = "txtuser"
        Me.txtuser.PlaceholderText = ""
        Me.txtuser.SelectedText = ""
        Me.txtuser.Size = New System.Drawing.Size(390, 55)
        Me.txtuser.TabIndex = 1
        '
        'txtPw
        '
        Me.txtPw.Animated = True
        Me.txtPw.BorderColor = System.Drawing.Color.SkyBlue
        Me.txtPw.BorderRadius = 10
        Me.txtPw.BorderThickness = 2
        Me.txtPw.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPw.DefaultText = ""
        Me.txtPw.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtPw.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtPw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPw.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtPw.FillColor = System.Drawing.SystemColors.Menu
        Me.txtPw.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPw.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtPw.ForeColor = System.Drawing.Color.DarkGray
        Me.txtPw.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPw.Location = New System.Drawing.Point(55, 285)
        Me.txtPw.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPw.Name = "txtPw"
        Me.txtPw.PlaceholderText = ""
        Me.txtPw.SelectedText = ""
        Me.txtPw.Size = New System.Drawing.Size(390, 55)
        Me.txtPw.TabIndex = 2
        '
        'checkPw
        '
        Me.checkPw.AutoSize = True
        Me.checkPw.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.checkPw.CheckedState.BorderRadius = 0
        Me.checkPw.CheckedState.BorderThickness = 0
        Me.checkPw.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.checkPw.Font = New System.Drawing.Font("Segoe UI Symbol", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkPw.Location = New System.Drawing.Point(88, 353)
        Me.checkPw.Name = "checkPw"
        Me.checkPw.Size = New System.Drawing.Size(110, 21)
        Me.checkPw.TabIndex = 3
        Me.checkPw.Text = "បង្ហាញ | Show"
        Me.checkPw.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.checkPw.UncheckedState.BorderRadius = 0
        Me.checkPw.UncheckedState.BorderThickness = 0
        Me.checkPw.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        '
        'BtnLogin
        '
        Me.BtnLogin.Animated = True
        Me.BtnLogin.BorderRadius = 20
        Me.BtnLogin.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnLogin.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnLogin.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnLogin.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnLogin.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnLogin.FillColor = System.Drawing.Color.Orchid
        Me.BtnLogin.Font = New System.Drawing.Font("Segoe UI Symbol", 9.0!, System.Drawing.FontStyle.Bold)
        Me.BtnLogin.ForeColor = System.Drawing.Color.White
        Me.BtnLogin.HoverState.FillColor = System.Drawing.Color.LightSkyBlue
        Me.BtnLogin.HoverState.FillColor2 = System.Drawing.Color.SkyBlue
        Me.BtnLogin.HoverState.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.BtnLogin.Location = New System.Drawing.Point(86, 387)
        Me.BtnLogin.Name = "BtnLogin"
        Me.BtnLogin.Size = New System.Drawing.Size(149, 58)
        Me.BtnLogin.TabIndex = 4
        Me.BtnLogin.Text = "ចូលប្រើ | Login"
        '
        'BtnCancel
        '
        Me.BtnCancel.Animated = True
        Me.BtnCancel.BorderRadius = 20
        Me.BtnCancel.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnCancel.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnCancel.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnCancel.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnCancel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnCancel.FillColor = System.Drawing.Color.Orchid
        Me.BtnCancel.Font = New System.Drawing.Font("Segoe UI Symbol", 9.0!, System.Drawing.FontStyle.Bold)
        Me.BtnCancel.ForeColor = System.Drawing.Color.White
        Me.BtnCancel.HoverState.FillColor = System.Drawing.Color.LightSkyBlue
        Me.BtnCancel.HoverState.FillColor2 = System.Drawing.Color.SkyBlue
        Me.BtnCancel.HoverState.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.BtnCancel.Location = New System.Drawing.Point(242, 387)
        Me.BtnCancel.Name = "BtnCancel"
        Me.BtnCancel.Size = New System.Drawing.Size(173, 58)
        Me.BtnCancel.TabIndex = 5
        Me.BtnCancel.Text = "ចាកចេញ | Cancel"
        '
        'BtnSignup
        '
        Me.BtnSignup.Animated = True
        Me.BtnSignup.BackColor = System.Drawing.Color.Transparent
        Me.BtnSignup.BorderColor = System.Drawing.Color.Transparent
        Me.BtnSignup.BorderRadius = 20
        Me.BtnSignup.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnSignup.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnSignup.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnSignup.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnSignup.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnSignup.FillColor = System.Drawing.Color.Transparent
        Me.BtnSignup.FillColor2 = System.Drawing.Color.Transparent
        Me.BtnSignup.Font = New System.Drawing.Font("Segoe UI Symbol", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSignup.ForeColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.BtnSignup.HoverState.FillColor = System.Drawing.Color.LightSkyBlue
        Me.BtnSignup.HoverState.FillColor2 = System.Drawing.Color.SkyBlue
        Me.BtnSignup.HoverState.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.BtnSignup.Location = New System.Drawing.Point(140, 490)
        Me.BtnSignup.Name = "BtnSignup"
        Me.BtnSignup.Size = New System.Drawing.Size(234, 58)
        Me.BtnSignup.TabIndex = 6
        Me.BtnSignup.Text = "បង្កើតគណនី | Sign Up"
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.Color.White
        Me.BtnClose.BorderColor = System.Drawing.Color.Transparent
        Me.BtnClose.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnClose.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnClose.FillColor = System.Drawing.Color.White
        Me.BtnClose.Font = New System.Drawing.Font("Segoe UI Symbol", 10.8!, System.Drawing.FontStyle.Bold)
        Me.BtnClose.ForeColor = System.Drawing.Color.Gray
        Me.BtnClose.HoverState.FillColor = System.Drawing.Color.Red
        Me.BtnClose.HoverState.ForeColor = System.Drawing.Color.White
        Me.BtnClose.Location = New System.Drawing.Point(460, 0)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(40, 31)
        Me.BtnClose.TabIndex = 8
        Me.BtnClose.Text = "X"
        '
        'Guna2CircleProgressBar1
        '
        Me.Guna2CircleProgressBar1.FillColor = System.Drawing.Color.LightCyan
        Me.Guna2CircleProgressBar1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar1.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar1.Location = New System.Drawing.Point(413, 37)
        Me.Guna2CircleProgressBar1.Minimum = 0
        Me.Guna2CircleProgressBar1.Name = "Guna2CircleProgressBar1"
        Me.Guna2CircleProgressBar1.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar1.Size = New System.Drawing.Size(168, 168)
        Me.Guna2CircleProgressBar1.TabIndex = 9
        Me.Guna2CircleProgressBar1.Text = "Guna2CircleProgressBar1"
        '
        'Guna2CircleProgressBar2
        '
        Me.Guna2CircleProgressBar2.FillColor = System.Drawing.Color.LightCyan
        Me.Guna2CircleProgressBar2.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar2.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar2.Location = New System.Drawing.Point(0, 554)
        Me.Guna2CircleProgressBar2.Minimum = 0
        Me.Guna2CircleProgressBar2.Name = "Guna2CircleProgressBar2"
        Me.Guna2CircleProgressBar2.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar2.Size = New System.Drawing.Size(156, 156)
        Me.Guna2CircleProgressBar2.TabIndex = 10
        Me.Guna2CircleProgressBar2.Text = "Guna2CircleProgressBar2"
        '
        'Guna2CircleProgressBar3
        '
        Me.Guna2CircleProgressBar3.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar3.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar3.Location = New System.Drawing.Point(6, 3)
        Me.Guna2CircleProgressBar3.Minimum = 0
        Me.Guna2CircleProgressBar3.Name = "Guna2CircleProgressBar3"
        Me.Guna2CircleProgressBar3.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar3.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar3.TabIndex = 11
        Me.Guna2CircleProgressBar3.Text = "Guna2CircleProgressBar3"
        '
        'Guna2CircleProgressBar4
        '
        Me.Guna2CircleProgressBar4.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar4.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar4.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar4.Location = New System.Drawing.Point(449, 552)
        Me.Guna2CircleProgressBar4.Minimum = 0
        Me.Guna2CircleProgressBar4.Name = "Guna2CircleProgressBar4"
        Me.Guna2CircleProgressBar4.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar4.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar4.TabIndex = 12
        Me.Guna2CircleProgressBar4.Text = "Guna2CircleProgressBar4"
        '
        'Guna2CircleProgressBar5
        '
        Me.Guna2CircleProgressBar5.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar5.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar5.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar5.Location = New System.Drawing.Point(0, 445)
        Me.Guna2CircleProgressBar5.Minimum = 0
        Me.Guna2CircleProgressBar5.Name = "Guna2CircleProgressBar5"
        Me.Guna2CircleProgressBar5.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar5.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar5.TabIndex = 13
        Me.Guna2CircleProgressBar5.Text = "Guna2CircleProgressBar5"
        '
        'Guna2CircleProgressBar6
        '
        Me.Guna2CircleProgressBar6.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar6.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar6.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar6.Location = New System.Drawing.Point(86, 60)
        Me.Guna2CircleProgressBar6.Minimum = 0
        Me.Guna2CircleProgressBar6.Name = "Guna2CircleProgressBar6"
        Me.Guna2CircleProgressBar6.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar6.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar6.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar6.TabIndex = 14
        Me.Guna2CircleProgressBar6.Text = "Guna2CircleProgressBar6"
        '
        'Guna2CircleProgressBar7
        '
        Me.Guna2CircleProgressBar7.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar7.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar7.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar7.Location = New System.Drawing.Point(180, 12)
        Me.Guna2CircleProgressBar7.Minimum = 0
        Me.Guna2CircleProgressBar7.Name = "Guna2CircleProgressBar7"
        Me.Guna2CircleProgressBar7.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar7.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar7.TabIndex = 12
        Me.Guna2CircleProgressBar7.Text = "Guna2CircleProgressBar7"
        '
        'Guna2CircleProgressBar8
        '
        Me.Guna2CircleProgressBar8.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar8.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar8.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar8.Location = New System.Drawing.Point(359, 165)
        Me.Guna2CircleProgressBar8.Minimum = 0
        Me.Guna2CircleProgressBar8.Name = "Guna2CircleProgressBar8"
        Me.Guna2CircleProgressBar8.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar8.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar8.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar8.TabIndex = 12
        Me.Guna2CircleProgressBar8.Text = "Guna2CircleProgressBar8"
        '
        'Guna2CircleProgressBar9
        '
        Me.Guna2CircleProgressBar9.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar9.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar9.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar9.Location = New System.Drawing.Point(413, 347)
        Me.Guna2CircleProgressBar9.Minimum = 0
        Me.Guna2CircleProgressBar9.Name = "Guna2CircleProgressBar9"
        Me.Guna2CircleProgressBar9.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar9.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar9.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar9.TabIndex = 15
        Me.Guna2CircleProgressBar9.Text = "Guna2CircleProgressBar9"
        '
        'Guna2CircleProgressBar10
        '
        Me.Guna2CircleProgressBar10.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar10.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar10.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar10.Location = New System.Drawing.Point(367, 451)
        Me.Guna2CircleProgressBar10.Minimum = 0
        Me.Guna2CircleProgressBar10.Name = "Guna2CircleProgressBar10"
        Me.Guna2CircleProgressBar10.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar10.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar10.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar10.TabIndex = 16
        Me.Guna2CircleProgressBar10.Text = "Guna2CircleProgressBar10"
        '
        'Guna2CircleProgressBar11
        '
        Me.Guna2CircleProgressBar11.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar11.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar11.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar11.Location = New System.Drawing.Point(55, 490)
        Me.Guna2CircleProgressBar11.Minimum = 0
        Me.Guna2CircleProgressBar11.Name = "Guna2CircleProgressBar11"
        Me.Guna2CircleProgressBar11.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar11.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar11.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar11.TabIndex = 12
        Me.Guna2CircleProgressBar11.Text = "Guna2CircleProgressBar11"
        '
        'Guna2CircleProgressBar12
        '
        Me.Guna2CircleProgressBar12.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar12.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar12.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar12.Location = New System.Drawing.Point(413, 505)
        Me.Guna2CircleProgressBar12.Minimum = 0
        Me.Guna2CircleProgressBar12.Name = "Guna2CircleProgressBar12"
        Me.Guna2CircleProgressBar12.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar12.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar12.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar12.TabIndex = 17
        Me.Guna2CircleProgressBar12.Text = "Guna2CircleProgressBar12"
        '
        'Guna2CircleProgressBar13
        '
        Me.Guna2CircleProgressBar13.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar13.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar13.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar13.Location = New System.Drawing.Point(336, 37)
        Me.Guna2CircleProgressBar13.Minimum = 0
        Me.Guna2CircleProgressBar13.Name = "Guna2CircleProgressBar13"
        Me.Guna2CircleProgressBar13.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar13.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar13.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar13.TabIndex = 18
        Me.Guna2CircleProgressBar13.Text = "Guna2CircleProgressBar13"
        '
        'Guna2CircleProgressBar14
        '
        Me.Guna2CircleProgressBar14.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar14.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar14.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar14.Location = New System.Drawing.Point(55, 137)
        Me.Guna2CircleProgressBar14.Minimum = 0
        Me.Guna2CircleProgressBar14.Name = "Guna2CircleProgressBar14"
        Me.Guna2CircleProgressBar14.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar14.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar14.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar14.TabIndex = 19
        Me.Guna2CircleProgressBar14.Text = "Guna2CircleProgressBar14"
        '
        'Guna2CircleProgressBar15
        '
        Me.Guna2CircleProgressBar15.FillColor = System.Drawing.Color.Azure
        Me.Guna2CircleProgressBar15.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2CircleProgressBar15.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleProgressBar15.Location = New System.Drawing.Point(131, 162)
        Me.Guna2CircleProgressBar15.Minimum = 0
        Me.Guna2CircleProgressBar15.Name = "Guna2CircleProgressBar15"
        Me.Guna2CircleProgressBar15.ProgressColor2 = System.Drawing.Color.LightSeaGreen
        Me.Guna2CircleProgressBar15.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleProgressBar15.Size = New System.Drawing.Size(48, 48)
        Me.Guna2CircleProgressBar15.TabIndex = 20
        Me.Guna2CircleProgressBar15.Text = "Guna2CircleProgressBar15"
        '
        'Login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(500, 600)
        Me.Controls.Add(Me.Login1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Login"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        Me.Login1.ResumeLayout(False)
        Me.Login1.PerformLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Login1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents BtnClose As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnSignup As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents BtnCancel As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents BtnLogin As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents checkPw As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents txtPw As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtuser As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2CircleProgressBar2 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar1 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar15 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar14 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar13 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar12 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar11 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar10 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar9 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar8 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar7 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar6 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar5 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar4 As Guna.UI2.WinForms.Guna2CircleProgressBar
    Friend WithEvents Guna2CircleProgressBar3 As Guna.UI2.WinForms.Guna2CircleProgressBar
End Class
