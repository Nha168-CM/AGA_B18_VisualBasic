﻿Public Class Dashboard

    'Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    Me.Text = "Maximize and Minimize Example"
    '    Me.Size = New Size(800, 600)
    'End Sub
    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Dim response As Integer

        response = MessageBox.Show("Are you sure you want to exit ?", "Exit Application",
                   MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If response = vbYes Then
            Application.ExitThread()
        End If

    End Sub

    Private Sub BtnMax_Click(sender As Object, e As EventArgs) Handles BtnMax.Click
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub BtnMini_Click(sender As Object, e As EventArgs) Handles BtnMini.Click
        Me.WindowState = FormWindowState.Normal
    End Sub

End Class