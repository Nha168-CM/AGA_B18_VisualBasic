﻿Public Class Student
    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Dim response As Integer

        response = MessageBox.Show("Are you sure want to exit ?", "Exit Application",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If response = vbYes Then
            Application.ExitThread()
        End If

    End Sub

    Private Sub BtnMax_Click(sender As Object, e As EventArgs) Handles BtnMax.Click
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub BtnMini_Click(sender As Object, e As EventArgs) Handles BtnMini.Click
        Me.WindowState = FormWindowState.Normal
    End Sub

    Private Sub txtID_GotFocus(sender As Object, e As EventArgs) Handles txtID.GotFocus
        If txtID.Text = "Student ID" Then
            txtID.Text = ""
            txtID.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtID_LostFocus(sender As Object, e As EventArgs) Handles txtID.LostFocus
        If txtID.Text = "" Then
            txtID.Text = "Student ID"
            txtID.ForeColor = Color.DarkGray
        End If
    End Sub

    Private Sub txtNameKh_GotFocus(sender As Object, e As EventArgs) Handles txtNameKh.GotFocus
        If txtNameKh.Text = "Name Khmer" Then
            txtNameKh.Text = ""
            txtNameKh.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtNameKh_LostFocus(sender As Object, e As EventArgs) Handles txtNameKh.LostFocus
        If txtNameKh.Text = "" Then
            txtNameKh.Text = "Name Khmer"
            txtNameKh.ForeColor = Color.DarkGray
        End If
    End Sub

    Private Sub txtNameEng_GotFocus(sender As Object, e As EventArgs) Handles txtNameEng.GotFocus
        If txtNameEng.Text = "Name English" Then
            txtNameEng.Text = ""
            txtNameEng.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtNameEng_LostFocus(sender As Object, e As EventArgs) Handles txtNameEng.LostFocus
        If txtNameEng.Text = "" Then
            txtNameEng.Text = "Name English"
            txtNameEng.ForeColor = Color.DarkGray
        End If
    End Sub
    Private Sub txtDOB_GotFocus(sender As Object, e As EventArgs) Handles txtDOB.GotFocus
        If txtDOB.Text = "Date Of Birth" Then
            txtDOB.Text = ""
            txtDOB.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtDOB_LostFocus(sender As Object, e As EventArgs) Handles txtDOB.LostFocus
        If txtDOB.Text = "" Then
            txtDOB.Text = "Date Of Birth"
            txtDOB.ForeColor = Color.DarkGray
        End If
    End Sub
    Private Sub txtPOB_GotFocus(sender As Object, e As EventArgs) Handles txtPOB.GotFocus
        If txtPOB.Text = "Place Of Birth" Then
            txtPOB.Text = ""
            txtPOB.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtPOB_LostFocus(sender As Object, e As EventArgs) Handles txtPOB.LostFocus
        If txtPOB.Text = "" Then
            txtPOB.Text = "Place Of Birth"
            txtPOB.ForeColor = Color.DarkGray
        End If
    End Sub
    Private Sub txtAddress_GotFocus(sender As Object, e As EventArgs) Handles txtAddress.GotFocus
        If txtAddress.Text = "Address::" Then
            txtAddress.Text = ""
            txtAddress.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub txtAddress_LostFocus(sender As Object, e As EventArgs) Handles txtAddress.LostFocus
        If txtAddress.Text = "" Then
            txtAddress.Text = "Address::"
            txtAddress.ForeColor = Color.DarkGray
        End If
    End Sub
End Class
